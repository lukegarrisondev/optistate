<?php
/**
 * Plugin Name: Optimal State
 * Plugin URI: https://payhip.com/optistate
 * Description: Advanced WordPress optimization suite featuring integrated database cleanup and backup tools, page caching, and diagnostic tools.
 * Version: 1.2.1
 * Author: Luke Garrison
 * Author URI: https://payhip.com/optistate
 * Text Domain: optistate
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.5
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }
define('OPTISTATE_PLUGIN_FILE', __FILE__);
define('OPTISTATE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('OPTISTATE_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OPTISTATE_INCLUDES_DIR', OPTISTATE_PLUGIN_DIR . 'includes/');
spl_autoload_register(function ($class) { if (strpos($class, 'OPTISTATE') !== 0) { return; } $class_file = str_replace('_', '-', strtolower($class)); $file_path = OPTISTATE_INCLUDES_DIR . 'class-' . $class_file . '.php'; if (file_exists($file_path)) { require_once $file_path; } }); function optistate_init() { static $instance = null; if ($instance === null) { $instance = new OPTISTATE(); }  return $instance; }
add_action('init', function() { load_plugin_textdomain('optistate', false, dirname(plugin_basename(OPTISTATE_PLUGIN_FILE)) . '/languages'); }, 1);
add_action('init', 'optistate_init', 5);
register_activation_hook(__FILE__, 'optistate_activate');
register_deactivation_hook(__FILE__, 'optistate_deactivate');
function optistate_activate() { load_plugin_textdomain('optistate', false, dirname(plugin_basename(OPTISTATE_PLUGIN_FILE)) . '/languages'); OPTISTATE_Activation::activate(); }
function optistate_deactivate() { OPTISTATE_Activation::deactivate(); }